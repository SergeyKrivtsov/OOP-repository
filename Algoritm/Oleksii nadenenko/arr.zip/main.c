#include <stdio.h>
#include <stdlib.h>

void AllocateMemory(int ***arr, int n) {
    *arr = (int**) malloc(n * sizeof(int*)); 
    for (int i = 0; i < n; i++) {
        (*arr)[i] = (int*) malloc(n * sizeof(int));
    }
}

void Fill(int **arr, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            arr[i][j] = m;
        }
    }
}

void Print(int **arr, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", arr[i][j]); 
        }
        printf("\n"); 
    }
}

void Zeroing(int **arr, int n){
    int mid = n/2;
    int count = n-1;
    int j = 0;
    int i = 0;
    while (i < n && count != mid-1) {
        while (j < n && j != count) {
            arr[i][j] = 0;
            j++;
        }
        j = 0;
        i++;
        count--;
    }
    count = count+2;
    while (i < n ) {
        while (j < n && j != count) {
            arr[i][j] = 0;
            j++;
        }
        j = 0;
        i++;
        count++;
    }
}

void FreeMemory(int **arr, int n) {
    for (int i = 0; i < n; i++) {
        free(arr[i]);
    }
    free(arr); 
}

int main() {
    int n;
    int m;
    int **arr;

    puts("Put the size:");
    scanf("%d", &n);
    puts("Put the number:");
    scanf("%d", &m);

    AllocateMemory(&arr, n); 
    Fill(arr, n, m);
    Print(arr, n);
    puts("\n");
    Zeroing(arr, n);
    Print(arr, n);
    FreeMemory(arr, n); 
    return 0;
}
