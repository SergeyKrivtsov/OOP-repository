/*Олімпіада з програмування. Є два текстові файли. У першому міститься
інформація про країни-учасниці та подані ними командами у вигляді
набору рядків, у кожному з яких назва країни та перелік назв команд цієї
країни. У другому – перелік назв команд у порядку зайнятих ними місць
(передбачається, що немає команд із однаковими назвами). Потрібно
створити список списків: список назв країн, упорядкований за абеткою, і
для кожної країни – список команд із зазначенням зайнятого ними місця у
порядку зростання. Забезпечити операції додавання, видалення,
редагування та розумного пошуку інформації, виведення інформації в
розумному вигляді...
Надененко Олексій
МФ-21*/
#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>

using namespace std;

struct Team {
    string name;
    int place;
    Team* next;
};

struct Country {
    string name;
    Team* teams;
    Country* next;
};

Country* head = nullptr;

void add(const string& name) {
    if (name.empty()) {
        cout << "Назва країни не може бути порожньою.\n";
        return;
    }
    
    Country* newCountry = new Country{name, nullptr, nullptr};
    if (!head || head->name > name) {
        newCountry->next = head;
        head = newCountry;
    } else {
        Country* current = head;
        while (current->next && current->next->name < name) {
            current = current->next;
        }
        newCountry->next = current->next;
        current->next = newCountry;
    }
}

void addTeam(const string& country, const string& name, int place = -1) {
    if (country.empty() || name.empty()) {
        cout << "Назва країни або команди не може бути порожньою.\n";
        return;
    }
    
    Country* current = head;
    while (current && current->name != country) {
        current = current->next;
    }
    if (!current) {
        cout << "Країну " << country << " не знайдено.\n";
        return;
    }

    Team* newTeam = new Team{name, place, nullptr};
    if (!current->teams || (place != -1 && current->teams->place > place)) {
        newTeam->next = current->teams;
        current->teams = newTeam;
    } else {
        Team* teamCurrent = current->teams;
        while (teamCurrent->next && (place == -1 || teamCurrent->next->place < place)) {
            teamCurrent = teamCurrent->next;
        }
        newTeam->next = teamCurrent->next;
        teamCurrent->next = newTeam;
    }
}

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t");
    if (first == string::npos) return ""; 
    size_t last = str.find_last_not_of(" \t");
    return str.substr(first, (last - first + 1));
}

void load(const string& filename) {
    try {
        ifstream file(filename);
        if (!file) {
            throw runtime_error("Не вдалося відкрити файл " + filename);
        }

        string line;
        while (getline(file, line)) {
            size_t colonPos = line.find(':');
            if (colonPos == string::npos) continue;

            string countryName = trim(line.substr(0, colonPos));
            string teamsList = line.substr(colonPos + 1);
            add(countryName);

            size_t startPos = 0, commaPos;
            while ((commaPos = teamsList.find(',', startPos)) != string::npos) {
                string teamName = trim(teamsList.substr(startPos, commaPos - startPos));
                addTeam(countryName, teamName);
                startPos = commaPos + 1;
            }
            string teamName = trim(teamsList.substr(startPos));
            addTeam(countryName, teamName);
        }

        file.close();
    } catch (const exception& e) {
        cout << e.what() << endl;
    }
}

void loadRankings(const string& filename) {
    try {
        ifstream file(filename);
        if (!file) {
            throw runtime_error("Не вдалося відкрити файл " + filename);
        }

        string teamName;
        int place = 1;
        while (getline(file, teamName)) {
            Country* currentCountry = head;
            bool found = false;

            while (currentCountry) {
                Team* currentTeam = currentCountry->teams;
                while (currentTeam) {
                    if (currentTeam->name == teamName) {
                        currentTeam->place = place++;
                        found = true;
                        break;
                    }
                    currentTeam = currentTeam->next;
                }
                if (found) break;
                currentCountry = currentCountry->next;
            }

            if (!found) {
                cout << "Команду " << teamName << " не знайдено у жодній країні." << endl;
            }
        }

        file.close();
    } catch (const exception& e) {
        cout << e.what() << endl;
    }
}

void removeCountry(const string& name) {
    if (name.empty()) {
        cout << "Назва країни не може бути порожньою.\n";
        return;
    }
    
    Country* current = head;
    Country* previous = nullptr;

    while (current && current->name != name) {
        previous = current;
        current = current->next;
    }

    if (!current) {
        cout << "Країну " << name << " не знайдено.\n";
        return;
    }

    Team* teamCurrent = current->teams;
    while (teamCurrent) {
        Team* tempTeam = teamCurrent;
        teamCurrent = teamCurrent->next;
        delete tempTeam;
    }

    if (previous) {
        previous->next = current->next;
    } else {
        head = current->next;
    }
    delete current;

    cout << "Країну " << name << " видалено.\n";
}

void removeTeam(const string& name) {
    if (name.empty()) {
        cout << "Назва команди не може бути порожньою.\n";
        return;
    }

    Country* currentCountry = head;

    while (currentCountry) {
        Team* currentTeam = currentCountry->teams;
        Team* previousTeam = nullptr;

        while (currentTeam && currentTeam->name != name) {
            previousTeam = currentTeam;
            currentTeam = currentTeam->next;
        }

        if (currentTeam) {
            if (previousTeam) {
                previousTeam->next = currentTeam->next;
            } else {
                currentCountry->teams = currentTeam->next;
            }
            delete currentTeam;
            cout << "Команду " << name << " видалено.\n";
            return;
        }
        currentCountry = currentCountry->next;
    }

    cout << "Команду " << name << " не знайдено.\n";
}

void show() {
    Country* currentCountry = head;
    while (currentCountry) {
        cout << "Країна: " << currentCountry->name << endl;
        Team* currentTeam = currentCountry->teams;
        while (currentTeam) {
            cout << "  Команда: " << currentTeam->name 
                 << ", Місце: " << (currentTeam->place == -1 ? "не визначено" : to_string(currentTeam->place)) << endl;
            currentTeam = currentTeam->next;
        }
        currentCountry = currentCountry->next;
    }
}

void clear() {
    while (head) {
        Country* tempCountry = head;
        head = head->next;
        while (tempCountry->teams) {
            Team* tempTeam = tempCountry->teams;
            tempCountry->teams = tempCountry->teams->next;
            delete tempTeam;
        }
        delete tempCountry;
    }
}

void search(const string& name) {
    if (name.empty()) {
        cout << "Назва команди не може бути порожньою.\n";
        return;
    }

    Country* currentCountry = head;
    while (currentCountry) {
        Team* currentTeam = currentCountry->teams;
        while (currentTeam) {
            if (currentTeam->name == name) {
                cout << "Команда " << name << " належить країні " << currentCountry->name
                     << " та зайняла місце " << (currentTeam->place == -1 ? "не визначено" : to_string(currentTeam->place)) << endl;
                return;
            }
            currentTeam = currentTeam->next;
        }
        currentCountry = currentCountry->next;
    }
    cout << "Команду " << name << " не знайдено." << endl;
}

void renameTeam(const string& oldName, const string& newName) {
    if (oldName.empty() || newName.empty()) {
        cout << "Назва команди не може бути порожньою.\n";
        return;
    }

    Country* currentCountry = head;
    while (currentCountry) {
        Team* currentTeam = currentCountry->teams;
        while (currentTeam) {
            if (currentTeam->name == oldName) {
                currentTeam->name = newName;
                cout << "Назву команди " << oldName << " змінено на " << newName << "." << endl;
                return;
            }
            currentTeam = currentTeam->next;
        }
        currentCountry = currentCountry->next;
    }
    cout << "Команду " << oldName << " не знайдено." << endl;
}

void menu() {
    cout << "\n=== Меню ===\n";
    cout << "1. Додати країну\n";
    cout << "2. Додати команду\n";
    cout << "3. Змінити назву\n";
    cout << "4. Видалити країну\n";
    cout << "5. Видалити команду\n";
    cout << "6. Знайти команду\n";
    cout << "7. Показати всі дані\n";
    cout << "8. Вийти\n";
    cout << "Виберіть опцію: ";
}

int main() {
    load("countries.txt");
    loadRankings("ranking.txt");

    int choice;
    string countryName, teamName, newName;

    while (true) {
        menu();
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Введіть назву країни: ";
                cin >> ws;
                getline(cin, countryName);
                add(countryName);
                break;
            case 2:
                cout << "Введіть назву країни: ";
                cin >> ws;
                getline(cin, countryName);
                cout << "Введіть назву команди: ";
                getline(cin, teamName);
                addTeam(countryName, teamName);
                break;
            case 3:
                cout << "Введіть стару назву: ";
                cin >> ws;
                getline(cin, teamName);
                cout << "Введіть нову назву: ";
                getline(cin, newName);
                renameTeam(teamName, newName);
                break;
            case 4:
                cout << "Введіть назву країни: ";
                cin >> ws;
                getline(cin, countryName);
                removeCountry(countryName);
                break;
            case 5:
                cout << "Введіть назву команди: ";
                cin >> ws;
                getline(cin, teamName);
                removeTeam(teamName);
                break;
            case 6:
                cout << "Введіть назву команди: ";
                cin >> ws;
                getline(cin, teamName);
                search(teamName);
                break;
            case 7:
                show();
                break;
            case 8:
                cout << "Вихід з програми.\n";
                clear();
                return 0;
            default:
                cout << "Невірний вибір. Спробуйте ще раз.\n";
        }
    }
}
