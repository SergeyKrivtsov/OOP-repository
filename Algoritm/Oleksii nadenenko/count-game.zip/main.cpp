#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int val;
    struct Node *next;
} Node;

void push(Node **head, int v) {
    Node *temp = (Node*)malloc(sizeof(Node));
    temp->val = v;
    
    if (*head == NULL) {
        *head = temp;
        temp->next = *head;  // Make the list circular for the first node
    } else {
        Node *current = *head;
        while (current->next != *head) {
            current = current->next;
        }
        current->next = temp;
        temp->next = *head;
    }
}

void print(Node *head) {
    if (head == NULL) return;
    
    Node *temp = head;
    do {
        printf("%d ", temp->val);
        temp = temp->next;
    } while (temp != head);
    printf("\n");
}

void deleteNode(Node **head, Node *toDelete) {
    if (*head == NULL || toDelete == NULL) return;

    // If there's only one node in the list
    if (*head == toDelete && (*head)->next == *head) {
        free(toDelete);
        *head = NULL;
        return;
    }

    Node *prev = *head;
    while (prev->next != toDelete) {
        prev = prev->next;
    }

    // If the node to delete is the head, move the head
    if (toDelete == *head) {
        *head = (*head)->next;
    }

    prev->next = toDelete->next;
    free(toDelete);
}

void playGame(Node **head) {
    if (*head == NULL) return;

    Node *current = *head;
    Node *prev = NULL;

    int count = 0;
    while ((*head)->next != *head) {  // Keep going until only one node remains
        count++;
        prev = current;
        current = current->next;

        // When count reaches 2, remove the node
        if (count == 2) {
            printf("Removing %d\n", current->val);
            deleteNode(head, current);
            current = prev->next;  // Move to the next node after deletion
            count = 0;  // Reset the counter
        }
    }

    printf("Last remaining node is %d\n", (*head)->val);
}

int main() {
    int v;
    int n;
    Node *head = NULL; 
    
    puts("Enter the size of the list:");
    scanf("%d", &n);
    
    puts("Enter the values for the list:");
    for (int i = 0; i < n; i++) {
        scanf("%d", &v);
        push(&head, v);  
    }

    puts("Initial list:");
    print(head);

    puts("Starting the game:");
    playGame(&head);

    return 0;
}
