#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int val;
    struct Node *next;
} Node;

void push(Node **head) {
    int n;
    scanf("%d", &n);
    
    if (n == 0) {
        *head = NULL; 
    } else {
        *head = (Node*)malloc(sizeof(Node));
        if (*head == NULL) {
            perror("Failed to allocate memory");
            exit(EXIT_FAILURE);
        }
        (*head)->val = n;
        (*head)->next = NULL;
        push(&(*head)->next);
    }
}

void print(Node *head) {
    Node *temp = head;
    while (temp != NULL) {
        printf("%d ", temp->val);
        temp = temp->next;
    }
    printf("\n");
}

void deleteList(Node *head) {
    if (head == NULL) {
        return; 
    }
    
    deleteList(head->next); 
    free(head); 
}

int main() {
    Node *head = NULL;
    puts("Put the values! \n");
    printf("Enter a value (0 to stop): ");
    push(&head);
    print(head);
    return 0;
}
