/*Скласти програму, яка містить поточну інформацію про заявки
на авіаквитки. Кожна заявка включає: пункт призначення,
номер рейсу, прізвище та ініціали пасажира, бажану дату
вильоту.
Програма має забезпечувати:
• зберігання всіх заявок у вигляді двійкового дерева,
• додавання та видалення заявок,
• за заданим номером рейсу та датою вильоту виведення заявок
з їх подальшим видаленням,
• виведення всіх заявок.
Надененко Олексій МФ-21*/
#include <iostream>
#include <string>

using namespace std;

struct Ticket {
    string dest;
    int flight;
    string name;
    string date;

    Ticket* left;
    Ticket* right;

    Ticket(string d, int f, string n, string dt)
        : dest(d), flight(f), name(n), date(dt), left(nullptr), right(nullptr) {}
};

class Tree {
private:
    Ticket* root;

    Ticket* add(Ticket* node, string d, int f, string n, string dt) {
        if (node == nullptr)
            return new Ticket(d, f, n, dt);

        if (f < node->flight)
            node->left = add(node->left, d, f, n, dt);
        else if (f > node->flight)
            node->right = add(node->right, d, f, n, dt);
        else {
            if (dt < node->date)
                node->left = add(node->left, d, f, n, dt);
            else
                node->right = add(node->right, d, f, n, dt);
        }
        return node;
    }

    Ticket* del(Ticket* node, int f, string dt) {
        if (node == nullptr) return node;

        if (f < node->flight)
            node->left = del(node->left, f, dt);
        else if (f > node->flight)
            node->right = del(node->right, f, dt);
        else if (dt == node->date) {
            if (node->left == nullptr) {
                Ticket* temp = node->right;
                delete node;
                return temp;
            }
            else if (node->right == nullptr) {
                Ticket* temp = node->left;
                delete node;
                return temp;
            }
            Ticket* temp = min(node->right);
            node->flight = temp->flight;
            node->date = temp->date;
            node->dest = temp->dest;
            node->name = temp->name;
            node->right = del(node->right, temp->flight, temp->date);
        }
        return node;
    }

    Ticket* min(Ticket* node) {
        Ticket* cur = node;
        while (cur && cur->left != nullptr)
            cur = cur->left;
        return cur;
    }

    void show(Ticket* node) {
        if (node != nullptr) {
            show(node->left);
            cout << "Dest: " << node->dest << ", Flight: " << node->flight
                 << ", Name: " << node->name << ", Date: " << node->date << endl;
            show(node->right);
        }
    }

    void find(Ticket* node, int f, string dt) {
        if (node == nullptr) return;

        if (node->flight == f && node->date == dt) {
            cout << "Dest: " << node->dest << ", Flight: " << node->flight
                 << ", Name: " << node->name << ", Date: " << node->date << endl;
        }
        find(node->left, f, dt);
        find(node->right, f, dt);
    }

public:
    Tree() : root(nullptr) {
        // Автоматичне додавання кількох квитків для тестування
        add("New York", 1001, "Ivanov I.I.", "2024-12-01");
        add("Los Angeles", 1002, "Petrov P.P.", "2025-05-15");
        add("Chicago", 1003, "Sidorov S.S.", "2026-07-20");
        add("Miami", 1004, "Smirnov A.A.", "2024-03-10");
        add("San Francisco", 1005, "Kuznetsov K.K.", "2025-11-30");
    }

    void add(string d, int f, string n, string dt) {
        root = add(root, d, f, n, dt);
    }

    void del(int f, string dt) {
        root = del(root, f, dt);
    }

    void show() {
        show(root);
    }

    void find(int f, string dt) {
        find(root, f, dt);
    }
};

bool validateDate(const string& date) {
    if (date.length() != 10 || date[4] != '-' || date[7] != '-')
        return false;

    int year = stoi(date.substr(0, 4));
    int month = stoi(date.substr(5, 2));
    int day = stoi(date.substr(8, 2));

    if (year < 2024 || year > 2026) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 31) return false;

    return true;
}

void menu() {
    Tree tree;
    int ch;

    do {
        cout << "\n--- Menu ---\n";
        cout << "1. Add Ticket\n";
        cout << "2. Delete Ticket\n";
        cout << "3. Show All Tickets\n";
        cout << "4. Find Tickets by Flight and Date\n";
        cout << "5. Exit\n";
        cout << "Choice: ";
        cin >> ch;

        switch (ch) {
            case 1: {
                string d, n, dt;
                int f;
                cout << "Enter destination (or '0' to cancel): ";
                cin >> d;
                if (d == "0") break;

                cout << "Enter flight number (or '0' to cancel): ";
                cin >> f;
                if (f == 0) break;

                cout << "Enter name (or '0' to cancel): ";
                cin.ignore();
                getline(cin, n);
                if (n == "0") break;

                do {
                    cout << "Enter date (YYYY-MM-DD, or '0' to cancel): ";
                    cin >> dt;
                    if (dt == "0") break;
                    if (!validateDate(dt))
                        cout << "Invalid date. Please enter a date between 2024 and 2026, with month between 1 and 12, and day between 1 and 31.\n";
                } while (!validateDate(dt));

                if (dt == "0") break;

                tree.add(d, f, n, dt);
                cout << "Ticket added.\n";
                break;
            }
            case 2: {
                int f;
                string dt;
                cout << "Enter flight number to delete (or '0' to cancel): ";
                cin >> f;
                if (f == 0) break;

                do {
                    cout << "Enter date to delete (YYYY-MM-DD, or '0' to cancel): ";
                    cin >> dt;
                    if (dt == "0") break;
                    if (!validateDate(dt))
                        cout << "Invalid date. Please enter a date between 2024 and 2026, with month between 1 and 12, and day between 1 and 31.\n";
                } while (!validateDate(dt));

                if (dt == "0") break;

                tree.del(f, dt);
                cout << "Ticket deleted.\n";
                break;
            }
            case 3:
                cout << "All tickets:\n";
                tree.show();
                break;
            case 4: {
                int f;
                string dt;
                cout << "Enter flight number (or '0' to cancel): ";
                cin >> f;
                if (f == 0) break;

                do {
                    cout << "Enter date (YYYY-MM-DD, or '0' to cancel): ";
                    cin >> dt;
                    if (dt == "0") break;
                    if (!validateDate(dt))
                        cout << "Invalid date. Please enter a date between 2024 and 2026, with month between 1 and 12, and day between 1 and 31.\n";
                } while (!validateDate(dt));

                if (dt == "0") break;

                cout << "Tickets for flight " << f << " on " << dt << ":\n";
                tree.find(f, dt);
                break;
            }
            case 5:
                cout << "Exiting.\n";
                break;
            default:
                cout << "Invalid choice.\n";
        }
    } while (ch != 5);
}

int main() {
    menu();
    return 0;
}
