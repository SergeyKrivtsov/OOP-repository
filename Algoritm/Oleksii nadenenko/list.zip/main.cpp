#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int val;
    struct Node *next;
} Node;

void push(Node **head, int v) {
    Node *temp = (Node*)malloc(sizeof(Node));
    temp->val = v;
    temp->next = (*head);
    (*head) = temp;
}

void print(Node *head) {
    Node *temp = head;
    while (temp != NULL) {
        printf("%d ", temp->val);
        temp = temp->next;
    }
    printf("\n");
}

Node* getNth(Node* head, int n) {
    int counter = 0;
    while (counter < n && head) {
        head = head->next;
        counter++;
    }
    return head;
}

void deleteNth(Node **head, int n) {
    Node *prev = getNth(*head, n-1);
    Node *elm  = prev->next;
    prev->next = elm->next;
    free(elm);
}

void insert(Node *head, int n, int val) {
    int i = 0;
    Node *tmp = NULL;
    while (i < n && head->next) {
        head = head->next;
        i++;
    }
    tmp = (Node*) malloc(sizeof(Node));
    tmp->val = val;
    if (head->next) {
        tmp->next = head->next;
    } else {
        tmp->next = NULL;
    }
    head->next = tmp;
}

int valuedelete(Node **head, int t){
    Node *current;
    if (*head == NULL) return 0;
    if((*head)->val == t){
        current = *head;
        *head = (*head)->next;
        delete current;
        return valuedelete(head, t);
    }
    else
        return valuedelete(&((*head)->next), t);
}


int main() {
    int v;
    int n;
    int t;
    Node *head = NULL; 
    puts("put the size of the list");
    scanf("%d", &n);
    puts("Enter the values for the list:");
    for (int i = 0; i < n; i++) {
        scanf("%d", &v);
        push(&head, v);  
    }

    print(head);
    insert(head, 4, 9);
    print(head);
    deleteNth(&head, 4);    
    print(head);
    puts("What value would you like to delete?");
    scanf("%d", &t);
    valuedelete(&head, t);  
    print(head);
    
    return 0;
}
