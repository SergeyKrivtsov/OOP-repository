/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
using namespace std;

// Клас для пірамідального сортування
class HeapSort {
public:
    int comp = 0; // Лічильник порівнянь
    int mov = 0;  // Лічильник переміщень

    // Побудова піраміди
    void heapify(int arr[], int n, int i) {
        int largest = i;          // Ініціалізуємо корінь як найбільший
        int left = 2 * i + 1;     // Лівий дочірній елемент
        int right = 2 * i + 2;    // Правий дочірній елемент

        // Перевірка, чи лівий дочірній елемент більший за корінь
        if (left < n && arr[left] > arr[largest]) {
            largest = left;
            comp++;
        }

        // Перевірка, чи правий дочірній елемент більший за найбільший
        if (right < n && arr[right] > arr[largest]) {
            largest = right;
            comp++;
        }

        // Якщо найбільший не є коренем
        if (largest != i) {
            swap(arr[i], arr[largest]);
            mov++;

            // Рекурсивно викликаємо для ураженого піддерева
            heapify(arr, n, largest);
        }
    }

    // Основна функція сортування
    void sort(int arr[], int n) {
        // Побудова піраміди
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }

        // Видалення елементів із піраміди
        for (int i = n - 1; i > 0; i--) {
            swap(arr[0], arr[i]);
            mov++;

            // Виклик heapify для зменшеної піраміди
            heapify(arr, i, 0);
        }
    }
};

// Клас для багатострічкового злиття
class MultiwayMergeSort {
public:
    int comp = 0; // Лічильник порівнянь
    int mov = 0;  // Лічильник переміщень

    // Функція для багатострічкового злиття
    void multiwayMerge(int arr[], int left, int right, int step) {
        while (step < right - left + 1) {
            for (int i = left; i <= right; i += step * 2) {
                int mid = min(i + step - 1, right);
                int end = min(i + step * 2 - 1, right);

                if (mid < end) {
                    merge(arr, i, mid, end);
                }
            }
            step *= 2;
        }
    }

    // Злиття двох частин масиву
    void merge(int arr[], int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        int* L = new int[n1];
        int* R = new int[n2];

        for (int i = 0; i < n1; i++) {
            L[i] = arr[left + i];
        }
        for (int j = 0; j < n2; j++) {
            R[j] = arr[mid + 1 + j];
        }

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k++] = L[i++];
            } else {
                arr[k++] = R[j++];
            }
            comp++;
            mov++;
        }

        while (i < n1) {
            arr[k++] = L[i++];
            mov++;
        }
        while (j < n2) {
            arr[k++] = R[j++];
            mov++;
        }

        delete[] L;
        delete[] R;
    }

    // Основна функція сортування
    void sort(int arr[], int left, int right) {
        multiwayMerge(arr, left, right, 1);
    }
};

// Функція для генерації масивів
void generateArr(int* arr, int n, const string& caseType) {
    if (caseType == "best") {
        for (int i = 0; i < n; i++) {
            arr[i] = i + 1;
        }
    } else if (caseType == "worst") {
        for (int i = 0; i < n; i++) {
            arr[i] = n - i;
        }
    } else if (caseType == "average") {
        for (int i = 0; i < n; i++) {
            arr[i] = rand() % 1000000;
        }
    }
}

// Функція для копіювання масиву
void copyArr(int* arr, int* arrCopy, int size) {
    for (int i = 0; i < size; i++) {
        arrCopy[i] = arr[i];
    }
}

// Функція для виконання тестів та запису результатів у файл
void Tests(int n, const string& caseType, ofstream& outputFile) {
    int* arr = new int[n];
    generateArr(arr, n, caseType);

    // Тестування HeapSort
    HeapSort heapSort;
    int* arrCopy = new int[n];
    copyArr(arr, arrCopy, n);
    heapSort.sort(arrCopy, n);
    outputFile << "HeapSort (" << caseType << "): Порівнянь = "
               << heapSort.comp << ", переміщень = " << heapSort.mov << endl;

    // Тестування MultiwayMergeSort
    MultiwayMergeSort mergeSort;
    copyArr(arr, arrCopy, n);
    mergeSort.sort(arrCopy, 0, n - 1);
    outputFile << "MultiwayMergeSort (" << caseType << "): Порівнянь = "
               << mergeSort.comp << ", Переміщень = " << mergeSort.mov << endl;

    delete[] arr;
    delete[] arrCopy;
}
int main() {
    srand(time(0)); // Генератора випадкових чисел

    // Відкриття файлу для запису результатів
    ofstream outputFile("sort.txt");
    if (!outputFile) { 
        cerr << "Error" << endl; 
        return 1; 
    }

    // Масив розмірів масивів, які будуть тестуватися
    int sizes[] = {100, 1000, 10000, 100000, 1000000};
    // Масив типів тестових випадків
    string caseTypes[] = {"кращий", "найгірший", "нормальний"};

    // Цикл для тестування кожного розміру масиву
    for (int size : sizes) {
        outputFile << "\nТестуємо розмір масиву: " << size << "\n"; 
        for (const string& caseType : caseTypes) { 
            Tests(size, caseType, outputFile); 
        }
    }

    // Закриття файлу після запису результатів
    outputFile.close();
    cout << "Результати у sort.txt" << endl; 
    return 0; 
}

