/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int val;
    struct Node* next;
} Node;

Node* createNode(int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Помилка\n");
        exit(1);
    }
    newNode->val = value;
    newNode->next = NULL;
    return newNode;
}

void end(Node** head, int value) {
    Node* newNode = createNode(value);
    if (*head == NULL) {
        *head = newNode;
        newNode->next = *head; 
        return;
    }
    Node* temp = *head;
    while (temp->next != *head) {  
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->next = *head; 
}

void print(Node* head) {
    if (head == NULL) {
        printf("Список пуст\n");
        return;
    }
    Node* temp = head;
    printf("Элементы списка: ");
    do {
        printf("%d ", temp->val);
        temp = temp->next;
    } while (temp != head);
    printf("\n");
}

void delete(Node** head, int value) {
    if (*head == NULL) {
        printf("Список пуст, невозможно удалить элемент\n");
        return;
    }

    Node *temp = *head, *prev = NULL;

    if (temp->val == value && temp->next == *head) {
        free(temp);
        *head = NULL;  // Список пуст после удаления
        return;
    }
    if (temp->val == value) {
    
        while (temp->next != *head) {
            temp = temp->next;
        }
        temp->next = (*head)->next;
        free(*head);
        *head = temp->next;
        return;
    }


    while (temp->next != *head && temp->val != value) {
        prev = temp;
        temp = temp->next;
    }

    if (temp->val == value) {
        prev->next = temp->next;
        free(temp);
    } else {
        printf("Элемент %d не найден в списке\n", value);
    }
}


void deleteEveryThird(Node** head) {
    if (*head == NULL || (*head)->next == *head) {
        return;
    }

    Node *prev = *head, *temp = (*head)->next;
    int count = 1;

    while (*head != (*head)->next) {
        if (count == 2) {
            printf("Удаляю элемент: %d\n", temp->val);
            prev->next = temp->next;

          
            if (temp == *head) {
                *head = temp->next;
            }

            free(temp);
            temp = prev->next;
            count = 0; 
        } else {
            prev = temp;
            temp = temp->next;
        }
        count++;
    }
    printf("Остался элемент: %d\n", (*head)->val);
}

void freeList(Node* head) {
    if (head == NULL) return;

    Node* temp = head;
    Node* nextNode;

    do {
        nextNode = temp->next;
        printf("Освобождаю память для элемента: %d\n", temp->val);
        free(temp);
        temp = nextNode;
    } while (temp != head);
}

int main() {
    Node* head = NULL;
    int n, value, Delete;

    printf("Введите количество элементов списка: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Введите элемент %d: ", i + 1);
        scanf("%d", &value);
        end(&head, value); 
    }

    print(head);
       
    printf("Введите значение для удаления: ");
    scanf("%d", &Delete);
    delete(&head, Delete);

    print(head);


    deleteEveryThird(&head);
    print(head);

 
    freeList(head);

    return 0;
}

