/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

// Структура вузла дерева
struct Node {
    string word;
    Node* left;
    Node* right;

    Node(string w) : word(w), left(nullptr), right(nullptr) {}
};

// Додавання вузла до дерева
Node* insert(Node* root, string word) {
    if (root == nullptr)
        return new Node(word);

    if (word < root->word)
        root->left = insert(root->left, word);
    else if (word > root->word)
        root->right = insert(root->right, word);

    return root;
}

// Прямий обхід дерева
void preOrder(Node* root, char letter, int& count) {
    if (root == nullptr)
        return;

    // Перевірка першої літери
    if (!root->word.empty() && root->word[0] == letter) {
        cout << root->word << " ";
        count++;
    }

    preOrder(root->left, letter, count);
    preOrder(root->right, letter, count);
}

// Звільнення пам'яті
void freeTree(Node* root) {
    if (root == nullptr)
        return;
    freeTree(root->left);
    freeTree(root->right);
    delete root;
}

int main() {
    Node* root = nullptr;

    // Зчитування слів з файлу
    ifstream file("words.txt");
    if (!file) {
        cerr << "Не вдалося відкрити файл!" << endl;
        return 1;
    }

    string word;
    while (file >> word) {
        root = insert(root, word);
    }
    file.close();

    // Введення літери для пошуку
    char letter;
    cout << "Введіть літеру для пошуку: ";
    cin >> letter;

    // Пошук та виведення результату
    cout << "Слова, що починаються на '" << letter << "': ";
    int count = 0;
    preOrder(root, letter, count);
    cout << endl;

    cout << "Кількість слів: " << count << endl;

    // Звільнення пам'яті
    freeTree(root);
    return 0;
}

