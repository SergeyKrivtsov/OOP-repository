/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

const int HEIGHT = 10;
const int WIDTH = 10; 

// ANSI
const string RESET = "\033[0m";
const string RED = "\033[31m";
const string GREEN = "\033[32m";
const string YELLOW = "\033[33m";
const string BLUE = "\033[34m";
const string WHITE = "\033[37m";
const string GRAY = "\033[90m";

char lab[HEIGHT][WIDTH] = {
    {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
    {'#', 'S', '.', '.', '#', '.', '.', '.', '.', '#'},
    {'#', '#', '#', '.', '#', '.', '#', '#', '.', '#'},
    {'#', '.', '.', '.', '.', '.', '.', '#', '.', '#'},
    {'#', '#', '#', '#', '#', '.', '#', '#', '.', '#'},
    {'#', '.', '.', '.', '#', '.', '.', '.', '.', '#'},
    {'#', '#', '#', '.', '#', '#', '#', '#', '.', '#'},
    {'#', '.', '#', '.', '.', '.', '.', '#', '.', '#'},
    {'#', '.', '.', '.', '#', '#', '.', '.', 'E', '#'},
    {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#'}
};

// Координаты начальной и конечной точки
int playerX = 1, playerY = 1; // начальная позиция 'S'
int endX = 8, endY = 8;       // позиция 'E'

// Функция для отображения лабиринта с цветами
void printLab() {
    for (int i = 0; i < HEIGHT; ++i) {
        for (int j = 0; j < WIDTH; ++j) {
            if (i == playerX && j == playerY) {
                cout << GREEN << 'P' << RESET; // позиция игрока
            } else if (lab[i][j] == '#') {
                cout << YELLOW << lab[i][j] << RESET; // стены
            } else if (lab[i][j] == '.') {
                cout << WHITE << lab[i][j] << RESET; // свободные клетки
            } else if (lab[i][j] == 'S') {
                cout << BLUE << lab[i][j] << RESET; // начальная точка
            } else if (lab[i][j] == 'E') {
                cout << RED << lab[i][j] << RESET; // конечная точка
            } else {
                cout << lab[i][j]; // другие символы без цвета
            }
        }
        cout << endl;
    }
}

// Функция для перемещения игрока
bool movePlayer(const string& where) {
    int newX = playerX, newY = playerY;
  
    if (where == "W") newX -= 1;
    else if (where == "S") newX += 1;
    else if (where == "A") newY -= 1;
    else if (where == "D") newY += 1;
    else return false;

    // Проверка границ и препятствий
    if (newX >= 0 && newX < HEIGHT && newY >= 0 && newY < WIDTH && lab[newX][newY] != '#') {
        playerX = newX;
        playerY = newY;
        return true;
    }
    return false;
}

int main() {
    cout << "Добро пожаловать в лабиринт\n";

    while (true) {
        printLab();
        
        // Проверка, достиг ли игрок конца лабиринта
        if (playerX == endX && playerY == endY) {
            cout << "Поздравляем, вы достигли выхода!\n";
            break;
        }
        
        cout << "Ваш ход (W, A, S, D): ";
        string move;
        cin >> move;

        if (!movePlayer(move)) {
            cout << "Невозможно двигаться в этом направлении\n";
        }
    }

    return 0;
}
