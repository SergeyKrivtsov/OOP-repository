/******************************************************************************

Є два односпрямованих списка L та M, які зберігають назви тварин,
впорядковані за алфавітом. Написати функцію, яка додає до списку L
елементи, які є в списку M і відсутні в списку L, не порушуючи
впорядкованість.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

// Структура
struct Node {
    string data;
    Node* next;
};

// Створення нового вузла
Node* createNode(const string& val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = nullptr;
    return newNode;
}

// Вставка нового елемента в список у впорядкованому вигляді
void insertInOrder(Node*& head, const string& value) {
    Node* newNode = createNode(value);
    
// Перевірка на порожній список або вставка на початок
    if (!head || head->data > value) {
        newNode->next = head;
        head = newNode;
        return;
    }
// Пошук місця для вставки нового елемента
    Node* current = head;
    while (current->next && current->next->data < value) {
        current = current->next;
    }

    // Перевірка на існування елемента
    if (current->data == value || (current->next && current->next->data == value)) {
        delete newNode; // Звільняємо пам'ять, якщо елемент вже існує
        return;
    }
    
//Вставка нового елемента після вузла current
    newNode->next = current->next;
    current->next = newNode;
}

// Виведення списку
void printList(Node* head) {
    while (head) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

// Додавання елементів зі списку M до списку L
void mergeLists(Node*& L, Node* M) {
    while (M) {
        insertInOrder(L, M->data);
        M = M->next;
    }
}

// Створення списку з введених даних
Node* createList() {
    Node* head = nullptr;
    string animal;
    while (true) {
     cout << "Введіть назву тварини або \".\" для завершення: ";
      cin >> animal;
        if (animal == ".") {
            break;
        }
        insertInOrder(head, animal);
    }
    return head;
}

int main() {
    cout << "Створення списку L:" << endl;
    Node* L = createList();

    cout << "Створення списку M:" << endl;
    Node* M = createList();

    cout << "Список L перед злиттям: ";
    printList(L);

    cout << "Список M: ";
    printList(M);

    mergeLists(L, M);

    cout << "Список L після злиття: ";
    printList(L);

    // Очищення пам'яті
    while (L) {
        Node* temp = L;
        L = L->next;
        delete temp;
    }

    while (M) {
        Node* temp = M;
        M = M->next;
        delete temp;
    }

    return 0;
}

