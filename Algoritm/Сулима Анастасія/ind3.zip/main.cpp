/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

struct Node {
    string data;
    Node* prev;
    Node* next;

    Node(string value) : data(value), prev(nullptr), next(nullptr) {}
};

class Deque {
private:
    Node* head; // Вказівник на початок списку
    Node* tail; // Вказівник на кінець списку

public:
    Deque() : head(nullptr), tail(nullptr) {}

    // Додавання елемента на початок
    void push_front(string task) {
        Node* newNode = new Node(task);
        if (head == nullptr) {
            head = tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
    }

    // Додавання елемента в кінець
    void push_back(string task) {
        Node* newNode = new Node(task);
        if (tail == nullptr) {
            head = tail = newNode;
        } else {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
    }

    // Видалення елемента з початку
    string pop_front() {
        if (head == nullptr) {
            throw runtime_error("Пусто");
        }
        Node* temp = head;
        string value = temp->data;
        head = head->next;
        if (head != nullptr) {
            head->prev = nullptr;
        } else {
            tail = nullptr;
        }
        delete temp;
        return value;
    }

    // Видалення елемента з кінця
    string pop_back() {
        if (tail == nullptr) {
            throw runtime_error("Пусто");
        }
        Node* temp = tail;
        string value = temp->data;
        tail = tail->prev;
        if (tail != nullptr) {
            tail->next = nullptr;
        } else {
            head = nullptr;
        }
        delete temp;
        return value;
    }

    // Перевірка, чи черга порожня
    bool is_empty() const {
        return head == nullptr;
    }

    // Вивід елементів черги
    void print() const {
        if (is_empty()) {
            cout << "Пусто" << endl;
            return;
        }
        Node* current = head;
        cout << "Завдання: ";
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }

    // Звільнення пам'яті
    ~Deque() {
        while (!is_empty()) {
            pop_front();
        }
    }
};

int main() {
    Deque taskQueue;
    int choice;
    string task;

    do {
        cout << "\nМеню:\n";
        cout << "1. Додати завдання на початок\n";
        cout << "2. Додати завдання в кінець\n";
        cout << "3. Видалити завдання з початку\n";
        cout << "4. Видалити завдання з кінця\n";
        cout << "5. Вивести усі завдання\n";
        cout << "0. Вийти\n";
        cout << "Ведіть: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Додати завдання на початок: ";
            cin.ignore(); // Для очищення буфера
            getline(cin, task);
            taskQueue.push_front(task);
            break;
        case 2:
            cout << "Додати завдання в кінець: ";
            cin.ignore();
            getline(cin, task);
            taskQueue.push_back(task);
            break;
        case 3:
            try {
                cout << "Видалити завдання з початку: " << taskQueue.pop_front() << endl;
            } catch (const exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            try {
                cout << "Видалити завдання з кінця: " << taskQueue.pop_back() << endl;
            } catch (const exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 5:
            taskQueue.print();
            break;
        case 0:
            cout << "Вихід з програми" << endl;
            break;
        default:
            cout << "Щось пішло не так. Спробуй ввести ще раз" << endl;
        }
    } while (choice != 0);

    return 0;
}

