#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

// Функция добавляет элемент в конец кольцевого списка
void append(Node **head, int data) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    
    if (*head == NULL) {
        *head = newNode;
        newNode->next = *head;  // Создаем кольцевую структуру для первого элемента
    } else {
        Node *temp = *head;
        while (temp->next != *head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->next = *head;
    }
}

// Функция для отображения всех элементов кольцевого списка
void showList(Node *head) {
    if (head == NULL) return;
    
    Node *current = head;
    do {
        printf("%d ", current->data);
        current = current->next;
    } while (current != head);
    printf("\n");
}

// Функция для удаления конкретного элемента из списка
void deleteNode(Node **head, Node *target) {
    if (*head == NULL || target == NULL) return;

    // Удаляем последний оставшийся элемент
    if (*head == target && (*head)->next == *head) {
        free(target);
        *head = NULL;
        return;
    }

    Node *beforeTarget = *head;
    while (beforeTarget->next != target) {
        beforeTarget = beforeTarget->next;
    }

    // Если удаляется первый элемент, переносим голову
    if (target == *head) {
        *head = (*head)->next;
    }

    beforeTarget->next = target->next;
    free(target);
}

// Функция-игра: каждый второй элемент удаляется, пока не останется один
void startGame(Node **head) {
    if (*head == NULL) return;

    Node *current = *head;
    Node *lastVisited = NULL;
    int counter = 0;

    while ((*head)->next != *head) {  // Продолжаем, пока не останется один узел
        counter++;
        lastVisited = current;
        current = current->next;

        // Удаление каждого второго элемента
        if (counter == 2) {
            printf("Удаляется %d\n", current->data);
            deleteNode(head, current);
            current = lastVisited->next;  // Переходим к следующему после удаления
            counter = 0;  // Сбрасываем счётчик
        }
    }

    printf("Последний оставшийся элемент: %d\n", (*head)->data);
}

int main() {
    int data;
    int size;
    Node *head = NULL; 
    
    puts("Введите размер списка:");
    scanf("%d", &size);
    
    puts("Введите значения элементов:");
    for (int i = 0; i < size; i++) {
        scanf("%d", &data);
        append(&head, data);  
    }

    puts("Начальный список:");
    showList(head);

    puts("Начинаем игру:");
    startGame(&head);

    return 0;
}
