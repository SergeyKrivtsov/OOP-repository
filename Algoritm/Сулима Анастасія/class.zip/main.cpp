/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cmath>
using namespace std;

class Parallelogram 
{
    double base; 
    double height;
    double side;

public:

Parallelogram(double b, double h) {
        this->base = b;  
        this->height = h;
        this->side = 1.0;
    }
    Parallelogram(double b, double h, double s) {
        this->base = b;  
        this->height = h;
        this->side = s;
    }

    double area() {
        return base * height;
    }

    double perim() {
        return 2 * (base + side);
    }

    void input() {
        cout << "Введите основание, высоту и боковую сторону: ";
        cin >> base >> height >> side;
    }
        void output() {
        cout << "Основание: " << base << std::endl;
        cout << "Высота: " << height << std::endl;
        cout << "Боковая сторона: " << side << std::endl;
        cout << "Площадь: " << area() << std::endl;
        cout << "Периметр: " << perim() << std::endl;
    }
};

int main()
{
    double b, h, s;

    cout << "Введите основание, высоту и боковую сторону: ";
    cin >> b >> h >> s;

 Parallelogram para1(b, h);
 
 para1.output(); // вывод всех параметров
 
    Parallelogram* para2 = new Parallelogram(b, h, s);

  para2 -> output(); // вывод всех параметров
    delete para2;
    return 0;
}


