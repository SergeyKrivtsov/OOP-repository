#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Глобальні змінні для підрахунку порівнянь та переміщень
long long total_comparisons = 0; // Лічильник порівнянь
long long total_swaps = 0;       // Лічильник переміщень

// Функція для обміну двох елементів
void exchange(int *x, int *y) {
    total_swaps++; // Збільшення лічильника переміщень
    int temp = *x;
    *x = *y;
    *y = temp;
}

// Функція розділення масиву для алгоритму Швидкого сортування
int partition_array(int array[], int start, int end) {
    int pivot_element = array[end]; // Опорний елемент
    int smaller_index = start - 1;  // Індекс для елементів, менших за опорний
    for (int current_index = start; current_index < end; current_index++) {
        total_comparisons++; // Збільшення лічильника порівнянь
        if (array[current_index] < pivot_element) {
            smaller_index++;
            exchange(&array[smaller_index], &array[current_index]); // Обмін елементів
        }
    }
    exchange(&array[smaller_index + 1], &array[end]); // Розміщення опорного елемента
    return smaller_index + 1;                        // Повертає індекс розділення
}

// Реалізація алгоритму Швидкого сортування
void quick_sort(int array[], int start, int end) {
    if (start < end) {
        int partition_index = partition_array(array, start, end); // Розділення масиву
        quick_sort(array, start, partition_index - 1);            // Сортування лівої частини
        quick_sort(array, partition_index + 1, end);             // Сортування правої частини
    }
}

// Функція для заповнення масиву випадковими числами
void generate_random_data(int array[], int size) {
    for (int i = 0; i < size; i++) {
        array[i] = rand(); // Генерація випадкових значень
    }
}

// Функція для заповнення масиву у найкращому випадку (вже відсортований масив)
void generate_sorted_data(int array[], int size) {
    for (int i = 0; i < size; i++) {
        array[i] = i; // Заповнення послідовними числами
    }
}

// Функція для заповнення масиву у найгіршому випадку (зворотний порядок)
void generate_reversed_data(int array[], int size) {
    for (int i = 0; i < size; i++) {
        array[i] = size - i; // Заповнення у зворотному порядку
    }
}

int main() {
    // Розміри тестових масивів
    int test_sizes[] = {100, 1000, 10000, 100000, 1000000};
    int number_of_tests = 5; // Кількість тестів

    // Тестування для кожного розміру
    for (int test_index = 0; test_index < number_of_tests; test_index++) {
        int size = test_sizes[test_index]; // Поточний розмір масиву
        int *array = (int *)malloc(size * sizeof(int)); // Виділення пам'яті для масиву

        // Тест для випадкових даних
        generate_random_data(array, size);
        total_comparisons = 0;
        total_swaps = 0;
        quick_sort(array, 0, size - 1);
        printf("Random Data - Size: %d, Comparisons: %lld, Swaps: %lld\n", size, total_comparisons, total_swaps);

        // Тест для найкращого випадку
        generate_sorted_data(array, size);
        total_comparisons = 0;
        total_swaps = 0;
        quick_sort(array, 0, size - 1);
        printf("Best Case - Size: %d, Comparisons: %lld, Swaps: %lld\n", size, total_comparisons, total_swaps);

        // Тест для найгіршого випадку
        generate_reversed_data(array, size);
        total_comparisons = 0;
        total_swaps = 0;
        quick_sort(array, 0, size - 1);
        printf("Worst Case - Size: %d, Comparisons: %lld, Swaps: %lld\n", size, total_comparisons, total_swaps);

        free(array); // Звільнення пам'яті
    }
    return 0;
}
