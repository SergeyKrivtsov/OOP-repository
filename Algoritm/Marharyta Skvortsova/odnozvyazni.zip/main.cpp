#include <iostream>  // підключаю бібліотеку для вводу/виводу
#include <fstream>   // підключаю бібліотеку для роботи з файлами
#include <string>    // бібліотеку для роботи з рядками

using namespace std;  // щоб не писати std:: щоразу

//оголошую структуру студент
struct Student {
    string surname;  // призвище 
    string group;    // група 
    float avgGrade;  // середній бал 
};

// оголошую структуру для вузла односпрямованого списку
struct Node {
    Student student;  // зберігаються дані студента
    Node* next;       // вказівник на наступний вузол
};

// функція для завантаження списку студентів з файлу
void loadList(const char* filename, Node*& head) {
    ifstream file(filename);  // відкриваю файл для зчитування
    if (!file) {  // якщо файл не вдалося відкрити
        cout << "Помилка при завантаженні списку з файлу." << endl;
        return;  // виходжу з функції, якщо файл не вдалося відкрити
    }

    // читаю дані з файлу поки не досягну кінець
    while (!file.eof()) {
        Student s;  // оголошую змінну для збереження даних студента
        file >> s.surname >> s.group >> s.avgGrade;  // Зчитую прізвище, групу і середній бал

        Node* newNode = new Node;  // Створюю новий вузол
        newNode->student = s;      // Записую дані студента в новий вузол
        newNode->next = head;      // Новий вузол вказує на попередній перший вузол
        head = newNode;            // Оновлюю голову списку, щоб новий вузол став першим
    }
    file.close();  // Закриваю файл після зчитування
}

// Функція для перевірки, чи є студент в списку
bool isInList(Node* head, Student s) {
    Node* temp = head;  // Ініціалізую тимчасовий вказівник на голову списку
    while (temp) {  // Перевіряю всі елементи списку
        if (temp->student.surname == s.surname && temp->student.group == s.group) {
            return true;  // Якщо знайдений студент з таким самим прізвищем і групою, повертаю true
        }
        temp = temp->next;  // Перехожу до наступного вузла списку
    }
    return false;  // Якщо студент не знайдений, повертаю false
}

// Функція для створення нового списку L з елементів L1, яких немає в L2
void createListL(Node* L1, Node* L2, Node*& L) {
    Node* temp = L1;  // Починаю з голови списку L1
    while (temp) {  // Перебираю всі елементи списку L1
        if (!isInList(L2, temp->student)) {  // Якщо студент не знайдений у списку L2
            Node* newNode = new Node;  // Створюю новий вузол
            newNode->student = temp->student;  // Копіюю дані студента в новий вузол
            newNode->next = L;  // Новий вузол вказує на поточний перший елемент списку L
            L = newNode;  // Оновлюю голову списку L, щоб новий вузол став першим
        }
        temp = temp->next;  // Переходжу до наступного вузла списку L1
    }
}

// Функція для виведення студентів, середній бал яких перевищує заданий поріг
void printTopStudents(Node* L, float threshold) {
    Node* temp = L;  // Починаю з голови списку L
    while (temp) {  // Перебираю всі елементи списку L
        if (temp->student.avgGrade > threshold) {  // Якщо середній бал студента більше за поріг
            cout << temp->student.surname << " " << temp->student.group << " " << temp->student.avgGrade << endl;
            // Виводжу прізвище, групу та середній бал студента
        }
        temp = temp->next;  // Переходжу до наступного вузла списку
    }
}

// Основна функція
int main() {
    Node* L1 = nullptr;  // Створюю порожні списки
    Node* L2 = nullptr;
    Node* L = nullptr;

    loadList("list1.txt", L1);  // Завантажую список студентів з файлу list1.txt
    loadList("list2.txt", L2);  // Завантажую список студентів з файлу list2.txt
    createListL(L1, L2, L);     // Створюю список L з елементів L1, яких немає в L2

    float threshold;  // Оголошую змінну для порогу середнього балу
    cout << "Введіть поріг середнього балу: ";  // Прошу користувача ввести поріг
    cin >> threshold;  // Зчитую введений поріг

    cout << "Студенти з середнім балом більше " << threshold << ":" << endl;
    printTopStudents(L, threshold);  // Виводжу студентів зі списку L, чиї середні бали перевищують поріг

    return 0;  // Завершаю виконання програми
}
