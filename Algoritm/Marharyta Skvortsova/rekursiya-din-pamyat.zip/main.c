#include <stdio.h>
#include <stdlib.h>

// Определение структуры для узла списка
typedef struct Node {
    int val;
    struct Node *next;
} Node;

// Функция для добавления узлов в список
void push(Node **head) {
    int n;
    scanf("%d", &n);
    
    if (n == 0) {  // Остановка ввода при вводе 0
        *head = NULL; 
    } else {
        *head = (Node*)malloc(sizeof(Node));  // Выделение памяти под новый узел
        if (*head == NULL) {
            perror("Failed to allocate memory");
            exit(EXIT_FAILURE);
        }
        (*head)->val = n;  // Присваивание значения узлу
        (*head)->next = NULL;
        push(&(*head)->next);  // Рекурсивный вызов для следующего узла
    }
}

// Функция для вывода значений списка
void print(Node *head) {
    Node *temp = head;
    while (temp != NULL) {
        printf("%d ", temp->val);
        temp = temp->next;  // Переход к следующему узлу
    }
    printf("\n");
}

// Функция для удаления списка и освобождения памяти
void deleteList(Node *head) {
    if (head == NULL) {
        return;  // Базовый случай рекурсии
    }
    
    deleteList(head->next);  // Рекурсивно удаляем следующий узел
    free(head);  // Освобождаем текущий узел
}

int main() {
    Node *head = NULL;
    puts("Put the values! \n");
    printf("Enter a value (0 to stop): ");
    push(&head);  // Начинаем ввод значений
    print(head);  // Выводим список
    return 0;
}
