#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Глобальні змінні для обліку кількості порівнянь та обмінів
long long totalComparisons = 0;
long long totalSwaps = 0;

// Функція для заповнення масиву випадковими числами
void generateRandomArray(int *array, int length) {
    srand(time(NULL));
    for (int i = 0; i < length; i++) {
        array[i] = rand() % 10000; // Випадкові числа до 10000
    }
}

// Функція для заповнення масиву відсортованими числами (найкращий сценарій)
void generateSortedArray(int *array, int length) {
    for (int i = 0; i < length; i++) {
        array[i] = i;
    }
}

// Функція для заповнення масиву зворотно відсортованими числами (найгірший сценарій)
void generateReversedArray(int *array, int length) {
    for (int i = 0; i < length; i++) {
        array[i] = length - i;
    }
}

// Функція для копіювання частини масиву
void copySubArray(int *source, int start, int end, int *destination) {
    for (int i = start; i <= end; i++) {
        destination[i - start] = source[i];
    }
}

// Функція для об'єднання двох підмасивів
void mergeArrays(int *array, int leftStart, int leftEnd, int rightStart, int rightEnd) {
    int leftSize = leftEnd - leftStart + 1;
    int rightSize = rightEnd - rightStart + 1;
    int *leftPart = (int *)malloc(leftSize * sizeof(int));
    int *rightPart = (int *)malloc(rightSize * sizeof(int));
    
    // Копіюємо підмасиви
    copySubArray(array, leftStart, leftEnd, leftPart);
    copySubArray(array, rightStart, rightEnd, rightPart);
    
    int i = 0, j = 0, k = leftStart;
    
    // Злиття
    while (i < leftSize && j < rightSize) {
        totalComparisons++; // Порівняння
        if (leftPart[i] <= rightPart[j]) {
            array[k++] = leftPart[i++];
            totalSwaps++; // Переміщення
        } else {
            array[k++] = rightPart[j++];
            totalSwaps++; // Переміщення
        }
    }
    
    // Додаємо залишки
    while (i < leftSize) {
        array[k++] = leftPart[i++];
        totalSwaps++; // Переміщення
    }
    
    while (j < rightSize) {
        array[k++] = rightPart[j++];
        totalSwaps++; // Переміщення
    }
    
    free(leftPart);
    free(rightPart);
}

// Функція для пошуку початків природних підмасивів (runs)
int findRunsInArray(int *array, int length, int *runsStartIndexes) {
    int runCount = 0;
    runsStartIndexes[runCount++] = 0;
    
    for (int i = 1; i < length; i++) {
        totalComparisons++; // Порівняння для визначення меж runs
        if (array[i] < array[i - 1]) {
            runsStartIndexes[runCount++] = i;
        }
    }
    return runCount;
}

// Алгоритм природного сортування злиттям
void naturalMergeSortAlgorithm(int *array, int length) {
    int *runsStartIndexes = (int *)malloc((length + 1) * sizeof(int)); // Для зберігання початків runs
    
    while (1) {
        // Знаходимо runs
        int runCount = findRunsInArray(array, length, runsStartIndexes);
        if (runCount == 1) break; // Масив відсортований
        
        // Поступово зливаємо runs
        for (int i = 0; i < runCount - 1; i += 2) {
            int leftStart = runsStartIndexes[i];
            int leftEnd = runsStartIndexes[i + 1] - 1;
            int rightStart = runsStartIndexes[i + 1];
            int rightEnd = (i + 2 < runCount) ? runsStartIndexes[i + 2] - 1 : length - 1;
            mergeArrays(array, leftStart, leftEnd, rightStart, rightEnd);
        }
    }
    
    free(runsStartIndexes);
}

// Основна функція для тестування
int main() {
    // Розміри тестових масивів
    int testSizes[] = {100, 1000, 10000};
    int totalTests = 3;
    
    for (int test = 0; test < totalTests; test++) {
        int arraySize = testSizes[test];
        int *array = (int *)malloc(arraySize * sizeof(int));
        
        // Тест для випадкових даних
        generateRandomArray(array, arraySize);
        totalComparisons = 0;
        totalSwaps = 0;
        naturalMergeSortAlgorithm(array, arraySize);
        printf("Random - Size: %d, Comparisons: %lld, Swaps: %lld\n", arraySize, totalComparisons, totalSwaps);
        
        // Тест для найкращого випадку
        generateSortedArray(array, arraySize);
        totalComparisons = 0;
        totalSwaps = 0;
        naturalMergeSortAlgorithm(array, arraySize);
        printf("Best Case - Size: %d, Comparisons: %lld, Swaps: %lld\n", arraySize, totalComparisons, totalSwaps);
        
        // Тест для найгіршого випадку
        generateReversedArray(array, arraySize);
        totalComparisons = 0;
        totalSwaps = 0;
        naturalMergeSortAlgorithm(array, arraySize);
        printf("Worst Case - Size: %d, Comparisons: %lld, Swaps: %lld\n", arraySize, totalComparisons, totalSwaps);
        
        free(array);
    }
    return 0;
}
