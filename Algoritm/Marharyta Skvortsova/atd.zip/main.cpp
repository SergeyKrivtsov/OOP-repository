#include <iostream>
#include <cstring>
using namespace std;

// Структура для елемента списку (пацієнт)
struct Patient {
    int id;                 // Ідентифікатор пацієнта
    char name[50];          // Ім'я пацієнта
    Patient* next;          // Вказівник на наступного пацієнта
};

// Структура для черги
struct Queue {
    Patient* front;         // Початок черги
    Patient* rear;          // Кінець черги
    int size;               // Поточний розмір черги
    int max_size;           // Максимальний розмір черги

    // Конструктор для створення черги з фіксованим розміром
    Queue(int max_size) : front(nullptr), rear(nullptr), size(0), max_size(max_size) {}
    
    // Функція для додавання пацієнта в чергу
    void enqueue(int id, const char* name) {
        if (size >= max_size) {
            cout << "Черга переповнена! Немає місця для нового пацієнта." << endl;
            return;
        }

        Patient* new_patient = new Patient;
        new_patient->id = id;
        snprintf(new_patient->name, sizeof(new_patient->name), "%s", name);
        new_patient->next = nullptr;

        if (rear == nullptr) {
            front = new_patient;
            rear = new_patient;
        } else {
            rear->next = new_patient;
            rear = new_patient;
        }

        size++;
        cout << "Пацієнт " << name << " (ID: " << id << ") доданий до черги." << endl;
    }

    // Функція для видалення пацієнта з черги
    void dequeue() {
        if (size == 0) {
            cout << "Черга порожня! Немає пацієнтів для обробки." << endl;
            return;
        }

        Patient* temp = front;
        front = front->next;

        if (front == nullptr) {
            rear = nullptr;
        }

        cout << "Пацієнт " << temp->name << " (ID: " << temp->id << ") оброблений і видалений з черги." << endl;
        delete temp;

        size--;
    }

    // Функція для перегляду пацієнтів у черзі
    void viewQueue() const {
        if (size == 0) {
            cout << "Черга порожня." << endl;
            return;
        }

        Patient* current = front;
        cout << "Пацієнти в черзі:" << endl;
        while (current != nullptr) {
            cout << "ID: " << current->id << ", Ім'я: " << current->name << endl;
            current = current->next;
        }
    }

    // Функція для звільнення пам'яті, зайнятої чергою
    ~Queue() {
        while (size > 0) {
            dequeue();
        }
    }
};

// Головна функція.Я все сделяль :)
int main() {
    int max_size = 5;
    Queue queue(max_size);

    queue.enqueue(1, "Іванов Іван");
    queue.enqueue(2, "Петренко Петро");
    queue.enqueue(3, "Сидоренко Лена");
    queue.enqueue(4, "Коваль Ната");
    queue.enqueue(5, "Шевченко Богдан");
    queue.enqueue(6, "Артемич");  // Цей пацієнт не буде доданий, бо черга переповнена

    queue.viewQueue();

    queue.dequeue();
    queue.dequeue();

    queue.viewQueue();

    return 0;
}
