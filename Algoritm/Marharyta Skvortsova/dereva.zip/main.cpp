#include <iostream>
#include <string>
using namespace std;

// Структура для представлення вузлів дерева
struct TreeNode {
    string value; // Символ 
    TreeNode* left; // Лівий 
    TreeNode* right; // Правий 

    // Конструктор для ініціалізації вузла
    TreeNode(string val) : value(val), left(nullptr), right(nullptr) {}
};

// Функція для створення прикладу дерева
TreeNode* createExampleTree() {
    // Створимо просте дерево для прикладу: ((3 + 5) * (2 - 4))
    TreeNode* root = new TreeNode("*");
    root->left = new TreeNode("+");
    root->right = new TreeNode("-");
    root->left->left = new TreeNode("3");
    root->left->right = new TreeNode("5");
    root->right->left = new TreeNode("2");
    root->right->right = new TreeNode("4");

    return root;
}

// Функція для перевірки балансу дужок в виразі, представленому деревом
bool checkParenthesesBalance(TreeNode* root, int& balance) {
    if (root == nullptr) {
        return true; // Порожній вузол, нічого не треба перевіряти
    }

    // Перевіряємо лівий піддерево
    bool leftBalanced = checkParenthesesBalance(root->left, balance);
    // Перевіряємо правий піддерево
    bool rightBalanced = checkParenthesesBalance(root->right, balance);

    // Якщо символ — відкриваюча дужка '('
    if (root->value == "(") {
        balance++;
    }
    // Якщо символ — закриваюча дужка ')'
    else if (root->value == ")") {
        balance--;
    }

    // Перевіряємо, чи не з'явилася неправильна кількість дужок
    if (balance < 0) {
        return false; // Якщо баланс від'ємний, значить дужки не збалансовані
    }

    return leftBalanced && rightBalanced;
}

bool isBalanced(TreeNode* root) {
    int balance = 0;
    return checkParenthesesBalance(root, balance) && (balance == 0);
}

// Функція для виведення дерева у вигляді тексту
void printTree(TreeNode* root, int space = 0, int COUNT = 10) {
    if (root == nullptr) {
        return;
    }

    // Збільшуємо відстань між рівнями
    space += COUNT;

    // Спочатку виводимо правий піддерево
    printTree(root->right, space);

    // Друкуємо поточний вузол
    cout << endl;
    for (int i = COUNT; i < space; i++) {
        cout << " ";
    }
    cout << root->value << endl;

    // Тепер виводимо лівий піддерево
    printTree(root->left, space);
}

int main() {
    // Створюємо дерево
    TreeNode* root = createExampleTree();

    // Перевіряємо баланс дужок
    if (isBalanced(root)) {
        cout << "Вираз врівноважений." << endl;
    } else {
        cout << "Вираз не збалансований." << endl;
    }

    // Виводимо дерево
    cout << "Структура дерева:" << endl;
    printTree(root);

    return 0;
}
