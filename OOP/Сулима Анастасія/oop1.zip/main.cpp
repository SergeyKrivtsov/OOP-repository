/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Базовий абстрактний клас
class Book {
protected:
    string title;
    string author;
    static int bookCount; // Статична змінна для підрахунку книг
public:
    Book(const string& t = "", const string& a = "") : title(t), author(a) {
        bookCount++;
    }
    virtual ~Book() {
        bookCount--;
    }
    static int getBookCount() {
        return bookCount;
    }

    virtual void displayInfo() const = 0; // Чисто віртуальний метод
    virtual void writeToFile(ofstream& out) const = 0;
    virtual void readFromFile(ifstream& in) = 0;
};

// Ініціалізація статичної змінної
int Book::bookCount = 0;

// Художня література
class FictionBook : public Book {
    string genre;
public:
    FictionBook(const string& t = "", const string& a = "", const string& g = "") 
        : Book(t, a), genre(g) {}

    void displayInfo() const override {
        cout << "Fiction Book - Title: " << title << ", Author: " << author 
             << ", Genre: " << genre << "\n";
    }

    void writeToFile(ofstream& out) const override {
        out << "Fiction\n" << title << "\n" << author << "\n" << genre << "\n";
    }

    void readFromFile(ifstream& in) override {
        getline(in, title);
        getline(in, author);
        getline(in, genre);
    }
};

// Клас-нащадок 2: Наукова література
class ScienceBook : public Book {
    int publicationYear;
public:
    ScienceBook(const string& t = "", const string& a = "", int y = 0) 
        : Book(t, a), publicationYear(y) {}

    void displayInfo() const override {
        cout << "Science Book - Title: " << title << ", Author: " << author 
             << ", Year: " << publicationYear << "\n";
    }

    void writeToFile(ofstream& out) const override {
        out << "Science\n" << title << "\n" << author << "\n" << publicationYear << "\n";
    }

    void readFromFile(ifstream& in) override {
        getline(in, title);
        getline(in, author);
        in >> publicationYear;
        in.ignore(); // Пропустити символ нового рядка
    }
};

// Функція для демонстрації роботи
void demonstrate() {
    try {
        // Створення об'єктів
        FictionBook fiction1("Fahrenheit 451", "Scott Fitzgerald", "Social fiction");
        ScienceBook science1("A Brief History of Time", "Stephen Hawking", 1988);

        // Виведення інформації
        fiction1.displayInfo();
        science1.displayInfo();

        cout << "Total Books: " << Book::getBookCount() << "\n";

        // Запис у файл
        ofstream outFile("books.txt");
        if (!outFile.is_open()) {
            throw runtime_error("Unable to open file for writing!");
        }
        fiction1.writeToFile(outFile);
        science1.writeToFile(outFile);
        outFile.close();

        // Читання з файлу
        ifstream inFile("books.txt");
        if (!inFile.is_open()) {
            throw runtime_error("Unable to open file for reading!");
        }
        string type;
        while (getline(inFile, type)) {
            if (type == "Fiction") {
                FictionBook fb;
                fb.readFromFile(inFile);
                fb.displayInfo();
            } else if (type == "Science") {
                ScienceBook sb;
                sb.readFromFile(inFile);
                sb.displayInfo();
            }
        }
        inFile.close();

        cout << "Books successfully read from file.\n";

    } catch (const runtime_error& err) {
        cerr << "Runtime Error: " << err.what() << "\n";
    } catch (const exception& ex) {
        cerr << "Error: " << ex.what() << "\n";
    } catch (...) {
        cerr << "Unknown error occurred.\n";
    }
}

int main() {
    demonstrate();
    return 0;
}
