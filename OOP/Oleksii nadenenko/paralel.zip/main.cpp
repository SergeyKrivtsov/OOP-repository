#include <iostream>
using namespace std;

class rect {
    int l;
    int w;
    int h;

public:
    rect() {
        cout << "Write the length: ";
        cin >> l;
        cout << "Write the width: ";
        cin >> w;
        cout << "Write the height: ";
        cin >> h;
        while(l<0 || w<0|| h<0 || l<h){
            cout << "you cannot put this numbers";
            cout << "Write the length: ";
            cin >> l;
            cout << "Write the width: ";
            cin >> w;
            cout << "Write the height: ";
            cin >> h;
        }
    }

    rect(int l, int w, int h) {
        this->l = l;
        this->w = w;
        this->h = h;
    }

    int square() {
        return w * h;
    }

    int perimetr() {
        return 2 * (l + w);
    }

    void print(int l, int w) {  
        cout << "Width: " << this->w << endl;
        cout << "Length: " << this->l << endl;
        cout << "Height: " << this->h << endl;
    }

    void print() {  
        cout << "Area: " << square() << endl;
        cout << "Perimeter: " << perimetr() << endl;
    }
};

int main() {
    rect rt[2] = {rect(2, 3, 1), rect()};
    for(int i =0; i<2; i++){
    rt[i].print(0, 0);
    rt[i].print();
    }

    return 0;
}