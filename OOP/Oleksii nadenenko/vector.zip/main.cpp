#include <iostream>
#include <cmath>
using namespace std;

class vector {
    int dimen;
    int* point;
public:
    vector(){
        cout << "put the dimensionality of the vector" << endl;
        cin >> dimen;
        point = new int [dimen];
        cout << "put the points" << endl;
        for(int i = 0; i<dimen; i++){
            cin >> point[i];
        }
    }
    double length(){
        double sum = 0;
        for (int i = 0; i<dimen; i++){
            sum += point[i]*point[i];
        }
        sum = sqrt(sum);
        return sum;
    }
    void print();
    ~vector(){
        delete point;
    }
};

void vector::print(){
    cout<<"the length is "<<length()<<endl;
}

int main()
{   
    int m;
    cout << "put the the number vectors" << endl;
    cin >> m;
    vector* v = new vector[m];
    for (int i = 0; i<m; i++){
        cout<<"vector number "<<i + 1<<" ";
        v[i].print();
    }
    vector rv(v[1]);
    cout<<"copied"<<endl;
    rv.print();
    delete[] v;

    return 0;
}