#include <iostream>
using namespace std;
#include <cstring>

class Point {
    int x;
    int y;

public:
    Point(int x, int y) {
        cout<<"Base constructor"<<endl;
        this->x = x;
        this->y = y;
    }
    virtual ~Point(){
        cout<<"Base distructor"<<endl;
    }
    virtual void print()const{cout<<"("<<x<<","<<y<<")";}
};

class CPoint: public Point{
    char* col;
public:
    CPoint(int x, int y, char* col):Point(x, y){
        cout<<"derived constructor"<<endl;
        this->col = new char[strlen(col)+1];
        strcpy(this->col,col);
    }
    ~CPoint(){
        cout<<"derived distructor"<<endl;
    }
    void print()const{
        Point::print();
        cout<<" "<<col<<endl;
    }
    
    void printcolour(){
        cout<<col<<endl;
    }
};

int main() {
    Point p = {Point (1,2)};
    p.print();
    Point *rp = new CPoint (1,1,"red");
    rp->print();
    CPoint* cp = dynamic_cast<CPoint*>(rp);
    cp->printcolour();
    delete rp;
    return 0;
}