#include <iostream>
#include <cmath>
using namespace std;

class vector {
    int dimen;
    int* point;
public:
    vector(int dimen, int* point){
        cout<<"Constructor"<<endl;
        this->dimen = dimen;
        this->point = new int [dimen];
        for(int i = 0; i<dimen; i++){
            this->point[i] = point[i];
        }
    }
    vector(const vector & p) {
        cout << "Copy Constructor" << endl;
        this->dimen = p.dimen;
        point = new int[p.dimen];
        for (int i = 0; i < dimen; i++) {
            this->point[i] = p.point[i];
        }
    }

    double length(){
        double sum = 0;
        for (int i = 0; i<dimen; i++){
            sum += point[i]*point[i];
        }
        sum = sqrt(sum);
        return sum;
    }
    void print();
    ~vector(){
        cout<<"destructor"<<endl;
        delete[] point;
    }
};

void vector::print(){
    //cout<<"the length is "<<length()<<endl;
    cout<<"(";
    for(int i = 0; i<dimen; i++){
        cout<<point[i]<<",";
    }
    cout<<")"<<endl;
}

void length(vector rv){
    cout<<"the length is "<<rv.length()<<endl;
}

int main()
{  
    int dimen;
    int* point;
     cout << "put the dimensionality of the vector" << endl;
        cin >> dimen;
        point = new int [dimen];
        cout << "put the points" << endl;
        for(int i = 0; i<dimen; i++){
            cin >> point[i];
        }
        vector rv(dimen, point);
        rv.print();
        length(rv);
        rv.print();

    return 0;
}