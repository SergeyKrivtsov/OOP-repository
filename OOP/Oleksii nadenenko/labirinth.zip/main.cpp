#include <iostream>
#include <chrono> // Для работы с временем
using namespace std;

// Определение цветных кодов ANSI
const string RESET = "\033[0m";
const string BLUE = "\033[34m";
const string PURPLE = "\033[35m";

void print(char arr[10][10], int x, int y) {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            if (i == x && j == y) {
                // Отображение игрока фиолетовым цветом
                cout << PURPLE << 'P' << RESET;
            } else if (arr[i][j] == 'S' || arr[i][j] == 'E') {
                // Отображение символов S и E синим цветом
                cout << BLUE << arr[i][j] << RESET;
            } else {
                // Отображение остальных символов без изменения цвета
                cout << arr[i][j];
            }
        }
        cout << endl;
    }
}

bool move(int &x, int &y, int dx, int dy, char arr[10][10]) {
    int newX = x + dx;
    int newY = y + dy;

    // Проверяем выход за границы лабиринта
    if (newX < 0 || newX >= 10 || newY < 0 || newY >= 10) {
        return false;
    }

    // Проверяем, что не наткнулись на стену
    if (arr[newX][newY] == '#') {
        return false;
    }

    // Перемещаем игрока
    x = newX;
    y = newY;

    // Проверяем, достиг ли игрок выхода
    return (arr[x][y] == 'E');
}

int main() {
    char arr[10][10] = {
        {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
        {'#', 'S', '.', '.', '#', '.', '.', '.', '.', '#'},
        {'#', '#', '#', '.', '#', '.', '#', '#', '.', '#'},
        {'#', '.', '.', '.', '.', '.', '.', '#', '.', '#'},
        {'#', '#', '#', '#', '#', '.', '#', '#', '.', '#'},
        {'#', '.', '.', '.', '.', '.', '.', '.', '.', '#'},
        {'#', '#', '#', '.', '#', '#', '#', '#', '#', '#'},
        {'#', '.', '#', '.', '.', '.', '.', '#', '.', '#'},
        {'#', '.', '.', '.', '#', '#', '.', '.', 'E', '#'},
        {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#'}
    };

    int x = 1, y = 1;
    char player;
    cout << "Цель: дойти до выхода (E). Управление: W (вверх), A (влево), S (вниз), D (вправо)\n";

    // Запускаем таймер
    auto start = chrono::steady_clock::now();
    const int TIME_LIMIT = 30; // Время в секундах

    // Основной цикл игры
    while (true) {
        // Проверяем, истекло ли время
        auto now = chrono::steady_clock::now();
        auto elapsed = chrono::duration_cast<chrono::seconds>(now - start).count();
        if (elapsed >= TIME_LIMIT) {
            cout << "Время вышло! Вы не успели добраться до выхода.\n";
            break;
        }

        print(arr, x, y);

        cout << "Осталось времени: " << (TIME_LIMIT - elapsed) << " секунд.\n";
        cout << "Ваш ход (W/A/S/D): ";
        cin >> player;

        bool exit = false;
        switch (player) {
            case 'W':
            case 'w':
                exit = move(x, y, -1, 0, arr);
                break;
            case 'A':
            case 'a':
                exit = move(x, y, 0, -1, arr);
                break;
            case 'S':
            case 's':
                exit = move(x, y, 1, 0, arr);
                break;
            case 'D':
            case 'd':
                exit = move(x, y, 0, 1, arr);
                break;
            default:
                cout << "Неверная команда! Попробуйте еще раз.\n";
                continue;
        }

        if (exit) {
            cout << "Поздравляем! Вы достигли выхода!\n";
            break;
        }
    }

    return 0;
}
