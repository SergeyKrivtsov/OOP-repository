#include <iostream>
using namespace std;

class rect {
    int l;
    int w;

public:
    rect() {
        cout << "Write the length: ";
        cin >> l;
        cout << "Write the width: ";
        cin >> w;
    }

    rect(int l, int w) {
        this->l = l;
        this->w = w;
    }

    int square() {
        return l * w;
    }

    int perimetr() {
        return 2 * (l + w);
    }

    void print(int l, int w) {  
        cout << "Width: " << this->w << endl;
        cout << "Length: " << this->l << endl;
    }

    void print() {  
        cout << "Area: " << square() << endl;
        cout << "Perimeter: " << perimetr() << endl;
    }
};

int main() {
    rect rt[2] = {rect(2, 3), rect()};
    for(int i =0; i<2; i++){
    rt[i].print(0, 0);
    rt[i].print();
    }

    return 0;
}