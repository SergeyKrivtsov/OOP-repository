#include <iostream>
#include <chrono> // Для работы с временем
#include <cstdlib> // Для rand() и srand()
#include <ctime>   // Для time()
using namespace std;

// Определение цветных кодов ANSI
const string RESET = "\033[0m";
const string BLUE = "\033[34m";
const string PURPLE = "\033[35m";

// Размер лабиринта
const int SIZE = 10;

// Функция для генерации лабиринта
void generate(char arr[SIZE][SIZE], int &exitX, int &exitY) {
    // Инициализируем случайный генератор
    srand(static_cast<unsigned int>(time(0)));

    // Заполняем лабиринт стенами
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            arr[i][j] = '#';
        }
    }

    // Устанавливаем стартовую точку (S)
    arr[1][1] = 'S';

    // Устанавливаем выход (E) в случайной позиции
    do {
        exitX = rand() % (SIZE - 2) + 1;
        exitY = rand() % (SIZE - 2) + 1;
    } while (exitX == 1 && exitY == 1); // Убедимся, что выход не совпадает со стартом
    
    arr[exitX][exitY] = 'E';  // Установка выхода
    // Генерируем путь от старта к выходу
    int x = 1, y = 1;
   // Двигаемся по x, пока не окажемся рядом с exitX (на расстоянии 1)
    while (x != exitX && x != exitX + 1 && x != exitX - 1) {
        if (x < exitX) x++;
        else if (x > exitX) x--;
        arr[x][y] = '.';  // Создаем проход по x
    }

    // Двигаемся по y, пока не окажемся рядом с exitY (на расстоянии 1)
    while (y != exitY && y != exitY + 1 && y != exitY - 1) {
        if (y < exitY) y++;
        else if (y > exitY) y--;
        arr[x][y] = '.';  // Создаем проход по y
    }



    // Добавляем случайные проходы, не перезаписывая `S` и `E`
for (int i = 1; i < SIZE - 1; i++) {
    for (int j = 1; j < SIZE - 1; j++) {
        // Проверяем, что это стена и не является стартовой или выходной точкой
        if (arr[i][j] == '#' && arr[i][j] != 'S' && arr[i][j] != 'E') {
            if (rand() % 2 == 0) { // 25% шанс на создание прохода
                arr[i][j] = '.'; // Превращаем стену в проход
            }
        }
    }
}

    // Вывод координат выхода для проверки
    cout << "Координаты выхода (E): (" << exitX << ", " << exitY << ")\n";
}

// Функция для отображения лабиринта
void print(char arr[SIZE][SIZE], int x, int y) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (i == x && j == y) {
                cout << PURPLE << 'P' << RESET;
            } else if (arr[i][j] == 'S' || arr[i][j] == 'E') {
                cout << BLUE << arr[i][j] << RESET;
            } else {
                cout << arr[i][j];
            }
        }
        cout << endl;
    }
}

// Функция для движения игрока
bool move(int &x, int &y, int dx, int dy, char arr[SIZE][SIZE]) {
    int newX = x + dx;
    int newY = y + dy;

    if (newX < 0 || newX >= SIZE || newY < 0 || newY >= SIZE || arr[newX][newY] == '#') {
        return false;
    }

    x = newX;
    y = newY;

    return (arr[x][y] == 'E');
}

int main() {
    char arr[SIZE][SIZE];
    int exitX, exitY; // Переменные для координат выхода

    generate(arr, exitX, exitY); // Генерация лабиринта

    int x = 1, y = 1; // Начальная позиция игрока
    char player;
    cout << "Цель: дойти до выхода (E). Управление: W (вверх), A (влево), S (вниз), D (вправо)\n";

    auto start = chrono::steady_clock::now();
    const int TIME_LIMIT = 30;

    // Основной цикл игры
    while (true) {
        auto now = chrono::steady_clock::now();
        auto elapsed = chrono::duration_cast<chrono::seconds>(now - start).count();
        if (elapsed >= TIME_LIMIT) {
            cout << "Время вышло! Вы не успели добраться до выхода.\n";
            break;
        }

        print(arr, x, y);
        
        cout << "Осталось времени: " << (TIME_LIMIT - elapsed) << " секунд.\n";
        cout << "Ваш ход (W/A/S/D): ";
        cin >> player;
        cout << endl;

        bool exit = false;
        switch (player) {
            case 'W':
            case 'w':
                exit = move(x, y, -1, 0, arr);
                break;
            case 'A':
            case 'a':
                exit = move(x, y, 0, -1, arr);
                break;
            case 'S':
            case 's':
                exit = move(x, y, 1, 0, arr);
                break;
            case 'D':
            case 'd':
                exit = move(x, y, 0, 1, arr);
                break;
            default:
                cout << "Неверная команда! Попробуйте еще раз.\n";
                continue;
        }

        if (exit) {
            cout << "Поздравляем! Вы достигли выхода!\n";
            break;
        }
    }

    return 0;
}
