#include <iostream>
using namespace std;

// Функція для виділення пам'яті під двовимірний динамічний масив
void memory(int **&arr, int N) {
    arr = new int*[N]; // Виділяємо пам'ять під масив вказівників (рядків)
    for (int i = 0; i < N; i++)
        arr[i] = new int[N]; // Для кожного рядка виділяємо пам'ять під елементи (стовпці)
}

// Функція для введення значень у двовимірний масив
void input(int **arr, int N) {
    for (int i = 0; i < N; i++) {
        cout << "Enter string number " << i + 1 << endl; // Виведення запиту для кожного рядка
        for (int j = 0; j < N; j++)
            cin >> arr[i][j]; // Введення елементів кожного рядка
    }
}

// Функція для виведення значень двовимірного масиву на екран
void print(int **arr, int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++)
            cout << arr[i][j] << " "; // Виведення кожного елемента в рядку
        cout << endl; // Переходимо на новий рядок після кожного рядка масиву
    }
}

// Функція для звільнення пам'яті, виділеної під двовимірний масив
void empty(int **arr, int N) {
    for (int i = 0; i < N; i++)
        delete[] arr[i]; // Видаляємо кожен рядок
    delete[] arr; // Видаляємо масив вказівників (рядків)
}

// Функція для множення кожного елемента масиву на 2
void multiply(int **arr, int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++)
            arr[i][j] = arr[i][j] * 2; // Множимо кожен елемент на 2
    }
}

int main() {
    int **arr; // Двовимірний масив
    int N; // Розмір масиву

    // Введення розміру масиву
    cout << "Put the size: ";
    cin >> N;

    // Виділення пам'яті для масиву
    memory(arr, N);
    
    // Введення елементів масиву
    input(arr, N);

    // Виведення оригінального масиву
    cout << "Original array:" << endl;
    print(arr, N);

    // Множення всіх елементів масиву на 2
    multiply(arr, N);
    
    // Виведення масиву після множення
    cout << "Array after multiplication by 2:" << endl;
    print(arr, N);

    empty(arr, N);// Звільнення пам'яті

    return 0;
}
