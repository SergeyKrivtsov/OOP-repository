#include <iostream>

using namespace std;

// Функція для підрахунку частоти чисел
void countFrequency(int nums[], int n, int freq[], int unique[], int &uniqueCount) {
    bool found;
    uniqueCount = 0;

    for (int i = 0; i < n; i++) {
        found = false;
        // Перевірка, чи число вже є у масиві унікальних чисел
        for (int j = 0; j < uniqueCount; j++) {
            if (unique[j] == nums[i]) {
                freq[j]++;
                found = true;
                break;
            }
        }
        // Якщо число не знайдено, додаємо його до унікальних
        if (!found) {
            unique[uniqueCount] = nums[i];
            freq[uniqueCount] = 1; // Перший раз зустріли, частота = 1
            uniqueCount++;
        }
    }
}

// Функція для сортування чисел за частотою та значенням
void sortByFrequency(int nums[], int n) {
    int freq[100] = {0};   // Массив для зберігання частоти
    int unique[100];       // Массив для зберігання унікальних чисел
    int uniqueCount = 0;

    // Підрахунок частоти
    countFrequency(nums, n, freq, unique, uniqueCount);

    // Сортування чисел за частотою та значенням
    for (int i = 0; i < uniqueCount; i++) {
        for (int j = i + 1; j < uniqueCount; j++) {
            // Якщо частота однакова, сортуємо за значенням у зворотному порядку
            if (freq[i] == freq[j]) {
                if (unique[i] < unique[j]) {
                    // Обмін значеннями
                    int temp = unique[i];
                    unique[i] = unique[j];
                    unique[j] = temp;

                    // Обмін частотами
                    int tempFreq = freq[i];
                    freq[i] = freq[j];
                    freq[j] = tempFreq;
                }
            }
            // Якщо частота різна, сортуємо за частотою
            else if (freq[i] > freq[j]) {
                // Обмін значеннями
                int temp = unique[i];
                unique[i] = unique[j];
                unique[j] = temp;

                // Обмін частотами
                int tempFreq = freq[i];
                freq[i] = freq[j];
                freq[j] = tempFreq;
            }
        }
    }

    // Формування результуючого масиву
    int result[100];
    int index = 0;

    for (int i = 0; i < uniqueCount; i++) {
        for (int j = 0; j < freq[i]; j++) {
            result[index++] = unique[i];
        }
    }

    // Виведення відсортованого масиву
    for (int i = 0; i < index; i++) {
        cout << result[i] << " ";
    }
    cout << endl;
}

int main() {
    int nums[] = {4, 5, 6, 5, 4, 3};
    int n = sizeof(nums) / sizeof(nums[0]);

    sortByFrequency(nums, n);

    return 0;
}
