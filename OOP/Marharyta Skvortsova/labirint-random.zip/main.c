#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef _WIN32
    #include <conio.h>  // For _getch() on Windows
#else
    #include <unistd.h>
    #define _getch getchar  // Use getchar() instead of _getch() on other OS
#endif

#define MAX_HEIGHT 20
#define MAX_WIDTH 20

// Maze dimensions
int MAZE_HEIGHT = 10;
int MAZE_WIDTH = 10;

// Maze representation
char maze[MAX_HEIGHT][MAX_WIDTH];

// Player coordinates
int player_x = 1;
int player_y = 1;

// Directions for maze generation
int dir[4][2] = { {0, 1}, {1, 0}, {0, -1}, {-1, 0} }; // right, down, left, up

// Function to display the maze
void displayMaze() {
    #ifdef _WIN32
        system("cls");  // Clear screen on Windows
    #else
        system("clear");  // Clear screen on Linux and macOS
    #endif

    for (int i = 0; i < MAZE_HEIGHT; i++) {
        for (int j = 0; j < MAZE_WIDTH; j++) {
            if (i == player_y && j == player_x) {
                printf("P ");  
            } else {
                printf("%c ", maze[i][j]);
            }
        }
        printf("\n");
    }
}

// Function to check if a position is inside the maze
int isInsideMaze(int x, int y) {
    return (x >= 0 && x < MAZE_WIDTH && y >= 0 && y < MAZE_HEIGHT);
}

// Function to check if the position is a wall
int isWall(int x, int y) {
    return maze[y][x] == '#';
}

// Function to initialize the maze with walls
void initializeMaze() {
    for (int i = 0; i < MAZE_HEIGHT; i++) {
        for (int j = 0; j < MAZE_WIDTH; j++) {
            maze[i][j] = '#';  // Fill maze with walls
        }
    }
}

// Function to generate the maze using Depth-First Search
void generateMaze(int x, int y) {
    maze[y][x] = '.';  // Mark the current cell as a path

    // Randomize directions
    for (int i = 0; i < 4; i++) {
        int randomIndex = rand() % 4;
        int temp[2] = {dir[i][0], dir[i][1]};
        dir[i][0] = dir[randomIndex][0];
        dir[i][1] = dir[randomIndex][1];
        dir[randomIndex][0] = temp[0];
        dir[randomIndex][1] = temp[1];
    }

    // Explore neighbors
    for (int i = 0; i < 4; i++) {
        int nx = x + dir[i][0] * 2;
        int ny = y + dir[i][1] * 2;

        if (isInsideMaze(nx, ny) && isWall(nx, ny)) {
            maze[y + dir[i][1]][x + dir[i][0]] = '.';  // Remove wall
            generateMaze(nx, ny);
        }
    }
}

// Function to place the start and end points in the maze
void placeStartAndEnd() {
    maze[1][1] = 'S';  // Start point
    maze[MAZE_HEIGHT - 2][MAZE_WIDTH - 2] = 'E';  // End point
}

// Function to check if the position is exit
int isExit(int x, int y) {
    return maze[y][x] == 'E';
}

// Function to check if the move is valid
int canMove(int x, int y) {
    return isInsideMaze(x, y) && maze[y][x] != '#';
}

// Main function
int main() {
    srand(time(NULL));  // Seed the random number generator

    // Get maze size from user
    printf("Enter maze height (max %d): ", MAX_HEIGHT);
    scanf("%d", &MAZE_HEIGHT);
    printf("Enter maze width (max %d): ", MAX_WIDTH);
    scanf("%d", &MAZE_WIDTH);

    // Adjust maze size to be odd to ensure valid paths
    if (MAZE_HEIGHT % 2 == 0) MAZE_HEIGHT++;
    if (MAZE_WIDTH % 2 == 0) MAZE_WIDTH++;

    initializeMaze();
    generateMaze(1, 1);  // Start generating the maze from (1, 1)
    placeStartAndEnd();   // Place start and end points

    char move;
    printf("Use WASD to move. Find the exit 'E'.\n");

    while (1) {
        displayMaze();

        // Input direction
        move = _getch(); 

        // Handle movement
        int new_x = player_x;
        int new_y = player_y;

        if (move == 'w') new_y--;
        else if (move == 's') new_y++;
        else if (move == 'a') new_x--;
        else if (move == 'd') new_x++;

        // Check movement
        if (canMove(new_x, new_y)) {
            player_x = new_x;
            player_y = new_y;

            // Check for exit
            if (isExit(player_x, player_y)) {
                displayMaze();
                printf("Congratulations! You've found the exit!\n");
                break;
            }
        }
    }

    return 0;
}
