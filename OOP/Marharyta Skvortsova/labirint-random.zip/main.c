#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef _WIN32
    #include <conio.h>  
#else
    #include <unistd.h>
    #define _getch getchar 
#endif

#define MAX_HEIGHT 20
#define MAX_WIDTH 20

int MAZE_HEIGHT = 10;
int MAZE_WIDTH = 10;

char maze[MAX_HEIGHT][MAX_WIDTH];

int player_x = 1;
int player_y = 1;

int dir[4][2] = { {0, 1}, {1, 0}, {0, -1}, {-1, 0} }; 

void displayMaze() {
    #ifdef _WIN32
        system("cls"); 
    #else
        system("clear");  
    #endif

    for (int i = 0; i < MAZE_HEIGHT; i++) {
        for (int j = 0; j < MAZE_WIDTH; j++) {
            if (i == player_y && j == player_x) {
                printf("P ");  
            } else {
                printf("%c ", maze[i][j]);
            }
        }
        printf("\n");
    }
}

int isInsideMaze(int x, int y) {
    return (x >= 0 && x < MAZE_WIDTH && y >= 0 && y < MAZE_HEIGHT);
}

int isWall(int x, int y) {
    return maze[y][x] == '#';
}

void initializeMaze() {
    for (int i = 0; i < MAZE_HEIGHT; i++) {
        for (int j = 0; j < MAZE_WIDTH; j++) {
            maze[i][j] = '#';  
        }
    }
}


void generateMaze(int x, int y) {
    maze[y][x] = '.';  

    for (int i = 0; i < 4; i++) {
        int randomIndex = rand() % 4;
        int temp[2] = {dir[i][0], dir[i][1]};
        dir[i][0] = dir[randomIndex][0];
        dir[i][1] = dir[randomIndex][1];
        dir[randomIndex][0] = temp[0];
        dir[randomIndex][1] = temp[1];
    }

    for (int i = 0; i < 4; i++) {
        int nx = x + dir[i][0] * 2;
        int ny = y + dir[i][1] * 2;

        if (isInsideMaze(nx, ny) && isWall(nx, ny)) {
            maze[y + dir[i][1]][x + dir[i][0]] = '.';
            generateMaze(nx, ny);
        }
    }
}

void placeStartAndEnd() {
    maze[1][1] = 'S';  // Start point
    maze[MAZE_HEIGHT - 2][MAZE_WIDTH - 2] = 'E'; 
}

int isExit(int x, int y) {
    return maze[y][x] == 'E';
}

int canMove(int x, int y) {
    return isInsideMaze(x, y) && maze[y][x] != '#';
}


int main() {
    srand(time(NULL));  

    printf("Enter maze height (max %d): ", MAX_HEIGHT);
    scanf("%d", &MAZE_HEIGHT);
    printf("Enter maze width (max %d): ", MAX_WIDTH);
    scanf("%d", &MAZE_WIDTH);


    if (MAZE_HEIGHT % 2 == 0) MAZE_HEIGHT++;
    if (MAZE_WIDTH % 2 == 0) MAZE_WIDTH++;

    initializeMaze();
    generateMaze(1, 1);  
    placeStartAndEnd(); 

    char move;
    printf("Use WASD to move. Find the exit 'E'.\n");

    while (1) {
        displayMaze();

        move = _getch(); 

        int new_x = player_x;
        int new_y = player_y;

        if (move == 'w') new_y--;
        else if (move == 's') new_y++;
        else if (move == 'a') new_x--;
        else if (move == 'd') new_x++;

        if (canMove(new_x, new_y)) {
            player_x = new_x;
            player_y = new_y;

            if (isExit(player_x, player_y)) {
                displayMaze();
                printf("Congratulations! You've found the exit!\n");
                break;
            }
        }
    }

    return 0;
}
