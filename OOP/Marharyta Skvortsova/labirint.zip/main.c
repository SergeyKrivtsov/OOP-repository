#include <stdio.h>
#include <stdlib.h>  // Функция system()
#ifdef _WIN32
    #include <conio.h>  // Для _getch() на Windows
#else
    #include <unistd.h>
    #define _getch getchar  // getchar() вместо _getch() на других ОС
#endif

#define MAZE_HEIGHT 10
#define MAZE_WIDTH 10

// Лабиринт
char maze[MAZE_HEIGHT][MAZE_WIDTH] = {
    {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
    {'#', 'S', '.', '.', '#', '.', '.', '.', '.', '#'},
    {'#', '#', '#', '.', '#', '.', '#', '#', '.', '#'},
    {'#', '.', '.', '.', '.', '.', '.', '#', '.', '#'},
    {'#', '#', '#', '#', '#', '.', '#', '.', '.', '#'},
    {'#', '.', '.', '.', '#', '.', '.', '.', '.', '#'},
    {'#', '#', '#', '.', '#', '#', '#', '.', '#', '#'},
    {'#', '.', '#', '.', '.', '.', '.', '.', '.', '#'},
    {'#', '.', '.', '.', '#', '#', '.', '.', 'E', '#'},
    {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#'}
};

// Координаты игрока
int player_x = 1;
int player_y = 1;

// Функция для отображения лабиринта
void displayMaze() {
    #ifdef _WIN32
        system("cls");  // Очистка экрана на Windows
    #else
        system("clear");  // Очистка экрана на Linux и macOS
    #endif

    for (int i = 0; i < MAZE_HEIGHT; i++) {
        for (int j = 0; j < MAZE_WIDTH; j++) {
            if (i == player_y && j == player_x) {
                printf("P ");  
            } else {
                printf("%c ", maze[i][j]);
            }
        }
        printf("\n");
    }
}

int isExit(int x, int y) {
    return maze[y][x] == 'E';
}

int canMove(int x, int y) {
    return maze[y][x] != '#';
}

// Основная функция
int main() {
    char move;
    printf("Use WASD to move. Find the exit 'E'.\n");

    while (1) {
        displayMaze();

        // Ввод направления
        move = _getch(); 

        // Обработка перемещения
        int new_x = player_x;
        int new_y = player_y;

        if (move == 'w') new_y--;
        else if (move == 's') new_y++;
        else if (move == 'a') new_x--;
        else if (move == 'd') new_x++;

        // Проверка перемещения
        if (canMove(new_x, new_y)) {
            player_x = new_x;
            player_y = new_y;

            // Выход
            if (isExit(player_x, player_y)) {
                displayMaze();
                printf("Congratulations! You've found the exit!\n");
                break;
            }
        }
    }

    return 0;
}