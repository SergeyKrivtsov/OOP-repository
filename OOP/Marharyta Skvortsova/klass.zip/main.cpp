#include <iostream>
#include <fstream>
#include <vector>
#include <memory>
#include <stdexcept>

// Абстрактний клас Figure
class Figure {
public:
    virtual double area() const = 0; // Абстрактний метод для обчислення площі
    virtual double perimeter() const = 0; // Абстрактний метод для обчислення периметру
    virtual void print() const = 0; // Абстрактний метод для виводу інформації про фігуру
    virtual ~Figure() {}
};

// Клас Circle, що успадковує Figure
class Circle : public Figure {
private:
    double radius;
    static int count;
public:
    Circle(double r) : radius(r) {
        if (r <= 0) throw std::invalid_argument("Радіус має бути позитивним");
        ++count;
    }
    double area() const override {
        return 3.14159 * radius * radius;
    }
    double perimeter() const override {
        return 2 * 3.14159 * radius;
    }
    void print() const override {
        std::cout << "Коло: радіус = " << radius
                  << ", область = " << area()
                  << ", периметр = " << perimeter() << std::endl;
    }
    static int getCount() {
        return count;
    }
    ~Circle() {
        --count;
    }
};
int Circle::count = 0;

// Клас Rectangle, що успадковує Figure
class Rectangle : public Figure {
private:
    double width, height;
    static int count;
public:
    Rectangle(double w, double h) : width(w), height(h) {
        if (w <= 0 || h <= 0) throw std::invalid_argument("Ширина і висота повинні бути додатними");
        ++count;
    }
    double area() const override {
        return width * height;
    }
    double perimeter() const override {
        return 2 * (width + height);
    }
    void print() const override {
        std::cout << "Прямокутник: ширина = " << width
                  << ", висота = " << height
                  << ", область = " << area()
                  << ", периметр = " << perimeter() << std::endl;
    }
    static int getCount() {
        return count;
    }
    ~Rectangle() {
        --count;
    }
};
int Rectangle::count = 0;

// Головна функція
int main() {
    try {
        std::vector<std::shared_ptr<Figure>> figures;

        // Додавання фігур
        figures.push_back(std::make_shared<Circle>(5.0));
        figures.push_back(std::make_shared<Rectangle>(4.0, 6.0));
        figures.push_back(std::make_shared<Circle>(3.0));

        // Виведення інформації про фігури
        for (const auto& figure : figures) {
            figure->print();
        }

        // Запис у файл
        std::ofstream outFile("figures.txt");
        if (!outFile) throw std::ios_base::failure("Неможливо відкрити файл для запису");

        for (const auto& figure : figures) {
            outFile << "Площа: " << figure->area() << ", Периметр: " << figure->perimeter() << std::endl;
        }
        outFile.close();

        // Статичні змінні
        std::cout << "Всього кіл: " << Circle::getCount() << std::endl;
        std::cout << "Всього прямокутників: " << Rectangle::getCount() << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
